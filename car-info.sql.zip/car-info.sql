-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2017-07-02 11:51:07
-- 服务器版本： 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car_info`
--

-- --------------------------------------------------------

--
-- 表的结构 `car`
--

CREATE TABLE `car` (
  `car_id` int(11) NOT NULL,
  `brand` char(255) COLLATE utf8mb4_bin NOT NULL,
  `model` char(255) COLLATE utf8mb4_bin NOT NULL,
  `engine` char(255) COLLATE utf8mb4_bin NOT NULL,
  `gearbox` char(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 转存表中的数据 `car`
--

INSERT INTO `car` (`car_id`, `brand`, `model`, `engine`, `gearbox`) VALUES
(1, 'Toyota', 'Camry', 'Petrol', 'Automatic'),
(2, 'Honda', 'Civic Type-R', 'Petrol', 'Manual'),
(3, 'Lexus', 'LX570', 'Petrol', 'Automatic'),
(4, 'Nissan', 'GT-R', 'Petrol', 'Automatic'),
(5, 'Mazda', 'RX-8', 'Petrol', 'Manual'),
(7, 'Toyota', 'Supra', 'Petrol', 'Manual'),
(8, 'Mitsubishi', 'Eclipse', 'Petrol', 'Manual'),
(9, 'Toyota', 'Land Cruiser', 'Petrol', 'Automatic'),
(10, 'Nissan', '370Z', 'Petrol', 'Manual');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`car_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `car`
--
ALTER TABLE `car`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
